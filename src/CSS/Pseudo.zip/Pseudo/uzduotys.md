# Pirma uzduotis

Susikurti kuba ir staciakampi naudojant css ir klases

Abieju stiliai turi buti nurodyti su dvieju klasiu selectorium

abieju klasiu selektorius turi turet nurodytus width, height, background, border

ir tuomet padidinti butent staciakampio auksti arba ploti.

# Antra uzduotis

I du elementus su tekstu "Cube" i kubas diva ir pakeisti teksto spalva i melyna pirmam tekstui o antra i zalia;

# Trecia uzduotis

Su pseudo klase pakeisti aplankytos nuorodos teksto spalva;

ir susikurti 3 input elementus su skirtingais tipais (text, number, email) ir ju background spalva pakeisti i lietuvos veliava;

# Ketvirta uzduotis

Sukurti lentele su 5 eilutem ir 6 stulpeliais

Lyginius stulpelius nuspalvinti pasirinkta spalva

ir nelyginius kita

odd/even

# Penkta uzduotis

Toje pacioje lenteleje kas antros eilutes, kas antra stulpeli nudazyti dar kita 

# Sesta uzduotis

Sukurti kuba kurio viduje butu kitas kubas ir jis butu iscentruotas su position property

# Namu darbas

Dokumentacija https://www.w3schools.com/cssref/css_selectors.asp

Nekeiciant nd.html pritaikyti nd.css komentaruose nurodytus stilius