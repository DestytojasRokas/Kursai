I "index.html" ideti ilgo texto elementa su maksimaliu simboliu skaicium 100 ir antraste "Description" ir jis yra privalomas

ideti checkbox elementa, jo antraste "Subscribe to newsletter?"

email input su veikiancia validacija (turetu neleisti validuoti ne email formato teksto)

Ideti mygtuka kuris forma pateiks

* Viska suvedus gerai, puslapis persikraus

* Padarius klaida, narsykle sufokusuos inputa kuris yra neteisingas.