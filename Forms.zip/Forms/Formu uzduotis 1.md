Susikurti "Forms" folderi

Jame sukurti "index.html"

"index.html" sukurti forma su vardo ir pavardes laukais (input)