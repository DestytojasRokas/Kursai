"index.html" sukurti select elementa su antraste Gyvunai

ir kokiais 5 pasirinkimais