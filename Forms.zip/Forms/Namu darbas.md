Sukurti registracijos forma

Forma turi tureti antraste "Register"

Laukai:
    First name (privalomas),
    Last name (privalomas),
    Email (validaus email patikrinimas, privalomas),
    Description (long text, max characters 200),
    Gender (du variantai su vienu pasirinkimu su type radio),
    Date of birth (Datos pasirinkimo input, privalomas)
    City of birth (Select, minimum 5 options)
    Address,
    Subscribe to newsletter (type checkbox)

Ideti mygtuka kuri paspaudus isvalo laukus.

Ideti mygtuka kuri paspaudus:

    * Viska suvedus gerai, puslapis turetu nuvesti i kita puslapi kuriame tekstas - "Congratulations your registration was succesful" 

    * Padarius klaida, narsykle sufokusuos inputa kuris yra neteisingas.

NAMU DARBAS TURI MATYTIS GITHUB REPOZITORIJOJE!